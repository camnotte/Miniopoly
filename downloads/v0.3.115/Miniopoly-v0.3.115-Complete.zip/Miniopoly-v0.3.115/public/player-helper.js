/* Personal, dismissible guidance. Bids and game decisions stay on the host. */
(function(root,factory){const api=factory((room,deeds)=>typeof module==='object'&&module.exports?require('./property-overview').wavePath(room,deeds):root.MiniopolyPropertyOverview.wavePath(room,deeds));if(typeof module==='object'&&module.exports)module.exports=api;else root.MiniopolyHelper=api;})(typeof window==='undefined'?globalThis:window,function(wavePath){
 'use strict';
 const money=n=>'$'+Number(n||0).toLocaleString('en-US');
 const scope=(room,id)=>[room?.code,room?.matchId,room?.youId,id].join(':');
 class ReadTracker{
  constructor(key,storage=typeof localStorage==='undefined'?null:localStorage){this.key=key;this.storage=storage;try{this.seen=new Set(JSON.parse(storage?.getItem(key)||'[]'));}catch{this.seen=new Set();}}
  has(room,id){return this.seen.has(scope(room,id));}
  mark(room,id){this.seen.add(scope(room,id));this.seen=new Set([...this.seen].slice(-200));this.save();}
  forget(room,id){this.seen.delete(scope(room,id));this.save();}
  save(){try{this.storage?.setItem(this.key,JSON.stringify([...this.seen]));}catch{}}
 }
 function auctionSummary(room,deeds,result=room?.collapse?.lastAuction){
  if(!result)return null;const catalog=Array.isArray(deeds)?Object.fromEntries(deeds.map(d=>[d.id,d])):deeds||{},me=room.players?.find(p=>p.id===room.youId);
  const lots=result.results.map(r=>({id:r.id,name:catalog[r.id]?.name||r.id,winner:r.winner,owner:r.winner===null?'Bank':room.players?.[r.winner]?.name||'Player',price:r.price,rebuildCost:Math.max(50,Math.ceil((catalog[r.id]?.price||0)/2)),you:!!me&&r.winner===me.seat,tied:!!r.tied,bids:r.bids||[]}));
  const wins=lots.filter(l=>l.you),ruins=wins.filter(l=>room.owned?.[l.id]?.owner===me.seat&&room.collapse?.lost?.[l.id]);
  return {id:result.id,wave:result.wave,lots,wins,ruins,rebuildTotal:ruins.reduce((n,l)=>n+l.rebuildCost,0),paid:wins.reduce((n,l)=>n+l.price,0),yourTurn:!!me&&room.turn===me.seat&&['roll','post'].includes(room.phase),cash:me?.availableCash??me?.cash??0};
 }
 function helperTip(room,deeds={}){
  const me=room?.players?.find(p=>p.id===room.youId);if(!me||me.out||room.stage!=='playing')return null;
  const s=room.collapse||{},mine=Object.entries(room.owned||{}).filter(([,o])=>o.owner===me.seat),cash=me.availableCash??me.cash,turn=room.turn===me.seat,safe=turn&&['roll','post'].includes(room.phase),catalog=Array.isArray(deeds)?Object.fromEntries(deeds.map(d=>[d.id,d])):deeds;
  if(s.auction)return {id:'auction:'+s.auction.id,title:'Bid while play continues',text:'Use the board timer to bid or pass; turns continue and sealed bids reserve cash.',action:'storm',label:'Open auction'};
  const sites=mine.filter(([id])=>s.lost?.[id]);
  if(sites.length){const cost=sites.reduce((n,[id])=>n+Math.max(50,Math.ceil((catalog[id]?.price||0)/2)),0),ready=safe&&cash>=cost;
   return {id:'rebuild:'+s.wave+':'+sites.map(([id])=>id).sort().join(',')+':'+(safe?'turn':'waiting')+':'+(cash>=cost?'funded':'short'),title:ready?'Rebuild your new sites':'Your redevelopment sites',text:safe?(cash>=cost?'Pay '+money(cost)+' to rebuild '+sites.length+' site'+(sites.length===1?'':'s')+' and restore rent and deed value.':'Rebuilding needs '+money(cost)+'. Save cash or sell/trade assets before spending more.'):'When your turn begins, open Storm preparations and rebuild your '+sites.length+' site'+(sites.length===1?'':'s')+' for '+money(cost)+'.',action:'rebuild',label:'Show rebuilding options'};
  }
  const offer=room.trades?.find(t=>t.to===me.seat&&t.status==='pending');if(offer){const type=offer.type;return {id:'trade:'+offer.id,title:type==='rent'?'Rent offer waiting':type==='swap'?'Position swap request':'Trade offer waiting',text:(room.players[offer.from]?.name||'A player')+(type==='rent'?' proposed $'+offer.amount+' to settle rent. Accept, decline or counter.':type==='swap'?' wants to swap positions. Review both locations before deciding.':' sent you a trade. Review the properties and cash before deciding.'),action:'trade',label:type?'Review offer':'Review trade'};}
  if(turn&&['rent','bail'].includes(room.phase))return {id:'payment:'+room.turnNumber+':'+room.phase,title:'Resolve your payment',text:'Review the '+money(room.obligation?.amount||room.pending?.amount)+' payment. Sell assets if you need more cash.',action:'landing',label:'Review landing'};
  if(room.gameMode==='countdown'&&s.direction&&!s.calm){const exposed=s.rule==='directional-v1'?new Set(wavePath(room,Object.values(catalog)).deeds.map(d=>d.id)):new Set(s.endangered||[]),count=mine.filter(([id])=>exposed.has(id)&&!s.lost?.[id]).length;
   if(count)return {id:'warning:'+s.wave+':'+s.direction,title:'Wave from '+s.direction.toUpperCase(),text:count+' of your properties are exposed. '+(s.wave?'Prepare before this round ends.':'Use rounds '+(room.rounds-1)+' and '+room.rounds+' to protect or trade them.'),action:'path',label:'See properties in the wave path'};
  }
  if(s.calm)return {id:'calm',title:'The ocean is calm',text:room.round<s.recoveryRound?'The final recovery round is next. Rebuild and review your net worth.':'This is the final recovery round. Rebuild and review your net worth before scoring.',action:'properties',label:'Review properties'};
  if(turn&&room.phase==='post'&&typeof window!=='undefined'&&window.MiniopolyPlayerAdvisor){const a=window.MiniopolyPlayerAdvisor.advise(room,catalog);if(['permit','develop','set'].includes(a?.key))return {id:'action:'+room.turnNumber+':'+a.key,title:'A useful next step',text:a.text,action:a.actions[0]||'properties',label:a.key==='set'?'Review trades':'Review development'};}
  if(turn&&room.round===1&&room.phase==='roll')return {id:'intro',title:'Your neighborhood helper',text:'Roll to explore. Buy properties, complete sets and develop them to increase rent.',action:null,label:''};
  if(room.gameMode==='countdown'){
   if(s.direction)return {id:'sheltered:'+s.wave+':'+s.direction,title:'Plan for the next wave',text:'Your properties are outside this wave’s path; save cash for blind auctions and rebuilding.',action:'path',label:'Review the wave path'};
   if(s.rule!=='directional-v1')return {id:'legacy-wave:'+s.wave+':'+room.round,title:'Prepare your properties',text:'Review your properties and save cash for development before the next wave.',action:'properties',label:'Review properties'};
   return {id:'building:'+room.round,title:'Prepare before the sirens',text:'Complete sets and save cash; sirens reveal the wave direction in round '+(room.rounds-1)+'.',action:'properties',label:'Review properties'};
  }
  return {id:'turn:'+room.round+':'+(turn?'yours':'waiting'),title:turn?'Your next move':'Plan while you wait',text:turn?(room.phase==='roll'?'Roll to explore, then review your landing before developing or trading.':'Review your properties and available actions before ending your turn.'):'Review your properties or negotiate a trade while '+(room.players[room.turn]?.name||'another player')+' takes a turn.',action:'properties',label:'Review properties'};
 }
 if(typeof document==='undefined')return {ReadTracker,auctionSummary,helperTip};
 class Display{
  constructor({getPreferences=()=>({helper:true}),getBusy=()=>false,onMute=()=>{},onOpen=()=>{},onAction=()=>{}}={}){
   Object.assign(this,{getPreferences,getBusy,onMute,onOpen,onAction});this.read=new ReadTracker('miniopoly_helper_seen_v1');try{this.minimized=localStorage.getItem('miniopoly_helper_minimized_v1')==='true';}catch{this.minimized=false;}
   this.element=document.createElement('aside');this.element.id='playerHelperBubble';this.element.className='player-helper-bubble';this.element.hidden=true;this.element.setAttribute('aria-label','Your player helper');
   this.element.innerHTML='<header><strong>Player helper</strong><button type="button" class="helper-dismiss" aria-label="Minimize player helper">−</button></header><div class="helper-content"><span class="helper-avatar" aria-hidden="true"></span><div><h3></h3><p role="status" aria-live="polite"></p></div></div><footer><button type="button" class="helper-action"></button><button type="button" class="helper-read">Read & minimize</button><button type="button" class="helper-mute">Mute helper</button></footer>';
   this.launcher=document.createElement('button');this.launcher.id='playerHelperLauncher';this.launcher.className='player-helper-launcher';this.launcher.type='button';this.launcher.hidden=true;this.launcher.setAttribute('aria-controls','playerHelperBubble');this.launcher.innerHTML='💬 <span class="helper-launcher-label">Helper</span> <span class="helper-unread-badge" hidden>1</span>';this.launcher.onclick=()=>{this.onOpen?.();this.minimize(false);};document.body.append(this.launcher);
   document.body.append(this.element);this.element.querySelector('.helper-dismiss').onclick=this.element.querySelector('.helper-read').onclick=()=>this.dismiss();this.element.querySelector('.helper-mute').onclick=()=>{this.onMute();this.minimize(true);};this.element.querySelector('.helper-action').onclick=()=>{const action=this.tip?.action;this.dismiss();if(action)this.onAction(action);};
   this.observer=new MutationObserver(()=>this.syncVisibility());this.observer.observe(document.body,{subtree:true,attributes:true,attributeFilter:['hidden','open']});document.addEventListener('visibilitychange',()=>this.syncVisibility());window.addEventListener('resize',()=>this.position());window.visualViewport?.addEventListener('resize',()=>this.position());window.visualViewport?.addEventListener('scroll',()=>this.position());
  }
  update(room,deeds){
   this.room=room;this.deeds=deeds;const enabled=this.getPreferences().helper!==false,tip=helperTip(room,deeds)||(room?.players?.some(p=>p.id===room.youId)?{id:'standby:'+room.stage,title:'Your player helper',text:room.stage==='lobby'?'Choose your avatar and game piece while everyone joins.':room.stage==='finished'?'The match is complete. Review the final standings.':'I’m here to help. Review your properties while waiting for your next move.',action:null,label:''}:null);
   if(this.enabled===false&&enabled&&tip){this.read.forget(room,tip.id);this.minimized=false;}this.enabled=enabled;this.tip=tip;
   if(tip){const me=room.players.find(p=>p.id===room.youId),identity=[me.avatar,me.avatarImage].join(':');if(identity!==this.identity){this.identity=identity;this.element.querySelector('.helper-avatar').innerHTML=window.MiniopolyAvatars.html(me.avatar,me.seat,me.avatarImage);}
    this.element.querySelector('h3').textContent=tip.title;this.element.querySelector('.helper-content p').textContent=tip.text;const action=this.element.querySelector('.helper-action');action.textContent=tip.label;action.hidden=!tip.action;
   }this.syncVisibility();
  }
  show(room=this.room,deeds=this.deeds){this.update(room,deeds);if(this.tip)this.read.forget(room,this.tip.id);this.minimize(false);}
  minimize(value){this.minimized=value;this.manualOpen=!value;try{localStorage.setItem('miniopoly_helper_minimized_v1',String(value));}catch{}this.syncVisibility();(value?this.launcher:this.element.querySelector('.helper-dismiss')).focus({preventScroll:true});}
  position(){const v=window.visualViewport,left=(v?.offsetLeft||0)+8,top=(v?.offsetTop||0)+8,width=v?.width||innerWidth,height=v?.height||innerHeight;for(const n of [this.element,this.launcher]){n.style.left=left+'px';n.style.bottom='auto';n.style.width=Math.max(0,Math.min(n===this.element?350:this.launcher.classList.contains('is-over-dialog')?46:145,width-16))+'px';n.style.maxHeight=Math.max(0,height-16)+'px';n.style.top=top+'px';if(!n.hidden)n.style.top=Math.max(top,top+height-16-n.getBoundingClientRect().height)+'px';}}
  syncVisibility(){const active=!!this.room?.players?.some(p=>p.id===this.room.youId),muted=this.getPreferences().helper===false,blocked=this.getBusy()||[...document.querySelectorAll('[role=dialog],dialog[open]')].some(n=>n.getClientRects().length&&!n.closest('[hidden]')),hidden=!active||!this.tip||muted||this.minimized||document.hidden||blocked&&!this.manualOpen;if(this.element.hidden!==hidden)this.element.hidden=hidden;const launcherHidden=!active||!hidden;if(this.launcher.hidden!==launcherHidden)this.launcher.hidden=launcherHidden;const unread=active&&!muted&&this.tip&&!this.read.has(this.room,this.tip.id),important=!!unread&&/^(warning|payment|trade|rebuild|auction|calm):?/.test(this.tip.id);const badge=this.launcher.querySelector('.helper-unread-badge');if(badge.hidden===important)badge.hidden=!important;this.launcher.classList.toggle('has-important-advice',important);this.launcher.classList.toggle('is-over-dialog',!!blocked);this.launcher.setAttribute('aria-label',muted?'Player helper muted. Open helper.':important?'Player helper: important unread advice. Open helper.':'Open player helper');this.launcher.setAttribute('aria-expanded',String(!hidden));this.element.classList.toggle('has-important-advice',important);this.position();}
  dismiss(){if(this.tip&&this.room)this.read.mark(this.room,this.tip.id);this.minimize(true);}

 }
 return {ReadTracker,auctionSummary,helperTip,Display};
});
